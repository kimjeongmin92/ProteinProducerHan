## Research question
-

## Data / target
- Dataset:
- Target:
- Variant:
- N active:
- N negative:

## Method / config
-

## Validation
- [ ] tests
- [ ] synthetic check
- [ ] real-data check
- [ ] reviewer reproduced key output

## Evidence
- Result:
- Figure:
- Issue:

## Limitation
-
